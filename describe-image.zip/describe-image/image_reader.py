# -*- coding: utf-8 -*-
"""View Image Plugin entry point."""

import logging

from qwenpaw.plugins.api import PluginApi

logger = logging.getLogger(__name__)


class ViewImagePlugin:
    """View Image Plugin.

    Registers describe_image tool into the Agent's toolkit.
    """

    def register(self, api: PluginApi):
        """Register describe_image tool.

        Args:
            api: PluginApi instance.
        """
        # Import tools module - plugin loader ensures plugin dir is in sys.path
        from . import image_tools

        api.register_tool(
            tool_name="describe_image",
            tool_func=image_tools.describe_image,
            description="Describe an image using VLM",
            icon="🖼️",
            enabled=True,
        )

        logger.info("view-image plugin registered")


# Export plugin instance
plugin = ViewImagePlugin()
